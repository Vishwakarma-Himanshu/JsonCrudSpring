package com.example.demo.utils;

public class Constants {

	public static final String SUCCESS = "Success";
	public static final String FAIL = "Fail";
	public static final String EMPLOYEE_ADDED_SUCCESSFULLY = "Employee Added Successfully";
	public static final String EMPLOYEE_ALREADY_PRESENT = "Employee ID Already Present";
	public static final String EMPLOYEE_DETAILS_UPDATED_SUCCESSFULLY = "Employee Details Updated Successfully";
	public static final String EMPLOYEE_DELETED_SUCCESSFULLY = "Employee Deleted Successfully";
	public static final String EMPLOYEE_NOT_FOUND = "Employee Not Found";
}
