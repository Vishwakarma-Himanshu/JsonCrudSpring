package com.example.demo.service;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.model.ResponseModel;
import com.example.demo.utils.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Override
	public ResponseModel addEmployee(Employee employee) {
		ResponseModel responseModel = new ResponseModel();
		List<Employee> employeeData = readJsonData();
		Employee employeePresent = null;
		
		if(employeeData != null) 
			employeePresent = employeeData.parallelStream().filter(emp -> emp.getId().equals(employee.getId())).findAny().orElse(null);
		else 
			employeeData = new ArrayList<>();
		
		if(employeePresent == null) {
			employeeData.add(employee);
			boolean status = writeJsonData(employeeData);
			
			if(status) {
				responseModel.setStatus(Constants.SUCCESS);
				responseModel.setData(Constants.EMPLOYEE_ADDED_SUCCESSFULLY);
			}
		}else {
			responseModel.setData(Constants.EMPLOYEE_ALREADY_PRESENT);
		}
		return responseModel;
		
	}
	
	public List<Employee> readJsonData(){
		List<Employee> employees = new ArrayList<>();
		try {
			String json = Files.readString(Path.of("employees.json"));
			employees = new Gson().fromJson(json, new TypeToken<List<Employee>>() {}.getType());
		}catch(Exception e) {
			e.printStackTrace();
		}
		return employees;
	}
	
	public boolean writeJsonData(List<Employee> employeeData) {
		boolean status = false;
		try(FileWriter file = new FileWriter("employees.json")){
			file.write(new Gson().toJson(employeeData));
			file.flush();
			
			status = true;
		}catch(IOException e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public ResponseModel fetchAllEmployee() {
		ResponseModel responseModel = new ResponseModel();
		List<Employee> employeeData = readJsonData();
		responseModel.setStatus(Constants.SUCCESS);
		responseModel.setData(employeeData);
		return responseModel;
	}

	@Override
	public ResponseModel fetchEmployeeDetails(String employeeId) {
		ResponseModel responseModel = new ResponseModel();
		List<Employee> employeeData = readJsonData();
		Employee employee = employeeData.parallelStream().filter(emp -> emp.getId().equals(employeeId)).findAny().orElse(null);
		
		if(employee != null) {
			responseModel.setStatus(Constants.SUCCESS);
			responseModel.setData(employee);
		}else {
			responseModel.setStatus(Constants.SUCCESS);
			responseModel.setData(Constants.EMPLOYEE_NOT_FOUND);
		}
		return responseModel;
	}

	@Override
	public ResponseModel updateEmployee(Employee employee) {
		ResponseModel responseModel = new ResponseModel();
		List<Employee> employeeData = readJsonData();
		employeeData.removeIf(emp -> emp.getId().equals(employee.getId()));
		employeeData.add(employee);
		
		boolean status = writeJsonData(employeeData);
		
		if(status) {
			responseModel.setStatus(Constants.SUCCESS);
			responseModel.setData(Constants.EMPLOYEE_DETAILS_UPDATED_SUCCESSFULLY);
		}
		return responseModel;
	}

	@Override
	public ResponseModel deleteEmployee(String employeeId) {
		ResponseModel responseModel = new ResponseModel();
		List<Employee> employeeData = readJsonData();
		employeeData.removeIf(emp -> emp.getId().equals(employeeId));
		
		boolean status = writeJsonData(employeeData);
		if(status) {
			responseModel.setStatus(Constants.SUCCESS);
			responseModel.setData(Constants.EMPLOYEE_DELETED_SUCCESSFULLY);
		}
		return responseModel;
	}

}
