package com.example.demo.service;

import com.example.demo.model.Employee;
import com.example.demo.model.ResponseModel;

public interface EmployeeService {

	ResponseModel addEmployee(Employee employee);

	ResponseModel fetchAllEmployee();

	ResponseModel fetchEmployeeDetails(String employeeId);

	ResponseModel updateEmployee(Employee employee);
	
	ResponseModel deleteEmployee(String employeeId);

}
